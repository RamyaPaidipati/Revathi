create database casestudy2; 

use casestudy2;

CREATE TABLE branches ( 
bid int(8) NOT NULL default '0', 
cid tinyint(4) NOT NULL default '0', 
bdesc varchar(255) NOT NULL default '', 
bloc char(3) NOT NULL default '' 
); 

INSERT INTO branches (bid, cid, bdesc, bloc) VALUES (1011, 101, 'Corporate HQ', 'CA'); 
INSERT INTO branches (bid, cid, bdesc, bloc) VALUES (1012, 101, 'Accounting Department', 'NY'); 
INSERT INTO branches (bid, cid, bdesc, bloc) VALUES (1013, 101, 'Customer Grievances Department', 'KA'); 
INSERT INTO branches (bid, cid, bdesc, bloc) VALUES (1041, 104, 'Branch Office (East)', 'MA'); 
INSERT INTO branches (bid, cid, bdesc, bloc) VALUES (1042, 104, 'Branch Office (West)', 'CA'); 
INSERT INTO branches (bid, cid, bdesc, bloc) VALUES (1101, 110, 'Head Office', 'CA'); 
INSERT INTO branches (bid, cid, bdesc, bloc) VALUES (1031, 103, 'N Region HO', 'ME'); 
INSERT INTO branches (bid, cid, bdesc, bloc) VALUES (1032, 103, 'NE Region HO', 'CT'); 
INSERT INTO branches (bid, cid, bdesc, bloc) VALUES (1033, 103, 'NW Region HO', 'NY'); 

CREATE TABLE branches_services ( 
bid int(8) NOT NULL default '0', 
sid tinyint(4) NOT NULL default '0' 
) ; 

INSERT INTO branches_services (bid, sid) VALUES (1011, 1); 
INSERT INTO branches_services (bid, sid) VALUES (1011, 2); 
INSERT INTO branches_services (bid, sid) VALUES (1011, 3); 
INSERT INTO branches_services (bid, sid) VALUES (1011, 4); 
INSERT INTO branches_services (bid, sid) VALUES (1012, 1); 
INSERT INTO branches_services (bid, sid) VALUES (1013, 5); 
INSERT INTO branches_services (bid, sid) VALUES (1041, 1); 
INSERT INTO branches_services (bid, sid) VALUES (1041, 4); 
INSERT INTO branches_services (bid, sid) VALUES (1042, 1); 
INSERT INTO branches_services (bid, sid) VALUES (1042, 4); 
INSERT INTO branches_services (bid, sid) VALUES (1101, 1); 
INSERT INTO branches_services (bid, sid) VALUES (1031, 2); 
INSERT INTO branches_services (bid, sid) VALUES (1031, 3); 
INSERT INTO branches_services (bid, sid) VALUES (1031, 4); 
INSERT INTO branches_services (bid, sid) VALUES (1032, 3); 
INSERT INTO branches_services (bid, sid) VALUES (1033, 4); 

CREATE TABLE clients ( 
cid tinyint(4) NOT NULL default '0', 
cname varchar(255) NOT NULL default '', 
PRIMARY KEY (cid) 
); 

INSERT INTO clients (cid, cname) VALUES (101, 'JV Real Estate'); 
INSERT INTO clients (cid, cname) VALUES (102, 'ABC Talent Agency'); 
INSERT INTO clients (cid, cname) VALUES (103, 'DMW Trading'); 
INSERT INTO clients (cid, cname) VALUES (104, 'Rabbit Foods Inc'); 
INSERT INTO clients (cid, cname) VALUES (110, 'Sharp Eyes Detective Agency'); 

CREATE TABLE services ( 
sid tinyint(4) NOT NULL default '0', 
sname varchar(255) NOT NULL default '', 
sfee float(6,2) NOT NULL default '0.00', 
PRIMARY KEY (sid) 
); 

INSERT INTO services (sid, sname, sfee) VALUES (1, 'Accounting', '1500.00'); 
INSERT INTO services (sid, sname, sfee) VALUES (2, 'Recruitment', '500.00'); 
INSERT INTO services (sid, sname, sfee) VALUES (3, 'Data Management', '300.00'); 
INSERT INTO services (sid, sname, sfee) VALUES (4, 'Administration', '500.00'); 
INSERT INTO services (sid, sname, sfee) VALUES (5, 'Customer Support', '2500.00'); 
INSERT INTO services (sid, sname, sfee) VALUES (6, 'Security', '600.00');

commit;